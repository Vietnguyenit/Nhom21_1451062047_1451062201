<!DOCTYPE html>
<html>
<head>
	<title>Results</title>
</head>
<body>
<?php 
	$conn = mysql_connect('localhost', 'root', '');
	mysql_select_db("bigdata");
	$res = mysql_query("select * from CHUYENMUC");
 ?>
<table>
 	<tr>
 		<td>ID</td>
 		<td>Title</td>
 		<td>Content</td>
 		<td>Del</td>
 	</tr>
 	<?php
 		while($row = mysql_fetch_array($res)){
	?>

	<tr>
		<td><?php echo $row['IDCMUC']; ?></td>
		<td><?php echo $row['TENCMUC']; ?></td>
		<td><?php echo $row['SOBAIVIET']; ?></td>
		<td><a href="16-5.php?id=17">Del</a></td> 
		<td><a href="16-5.php?id=<?php echo $row['id'] ;?>">Del</a></td> 
	</tr>
	<?php 
	}
	 ?>
 </table>
</body>
</html>
