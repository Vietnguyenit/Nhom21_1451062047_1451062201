
<?php 
	//include(''); loi van chay
	// require(''); loi stop
	// include_once('');
	// require_once('');

	$conn = mysqli_connect('localhost', 'root', '','bigdata');

	$email = $_POST['email'];
	$password = $_POST['password'];


	$email = stripcslashes($email);
	$password = stripcslashes($password);
	$email = mysqli_real_escape_string($conn , $email);
	$password = mysqli_real_escape_string($conn , $password);

	

	$results = mysqli_query($conn , "select * from REGISTER where EMAIL = '$email' and PASSWORD = '$password'") 
															or die("failed to query database".mysqli_error());




	//if(mysql_num_rows($results) >0 )
	
	$row  = mysqli_fetch_array($results);
	if($row['EMAIL'] == $email && $row['PASSWORD'] = $password){
		//header("Location:http://google.com.vn");
		echo "Haha";
	}
	else
	{
		echo "NO";
	}
	mysqli_close($conn);


	//function select_db($sql){
	//	return $abc;
	//}
 ?>

