
<?php
	$conn = mysqli_connect('localhost', 'root', '','bigdata');

	$fname = $_POST['ho'];
	$lname = $_POST['ten'];
	$sex = $_POST['sex'];
	$ages = $_POST['ages'];
	$pass = $_POST['password'];

	$email = $_POST['email'];

	$email = stripcslashes($email);
	$email = mysqli_real_escape_string($conn , $email);

	
	$results = mysqli_query($conn , "select * from REGISTER where EMAIL = '$email' ") 
															or die("failed to query database".mysqli_error());

	$add = " INSERT INTO REGISTER VALUES ('$fname' , '$lname','$ages','$sex', '$email','$pass')";

	//$rowr = mysql_num_rows($results);
	//echo $rowr;

	$row  = mysqli_fetch_array($results);
	if($row['EMAIL'] != $email ){
		if(mysqli_query($conn , $add)  == TRUE){
			header("Location:success.php");
		} 
		else {
			header("Location:index.php");
		}
	}
	else
	{	
		header("Location:index.php");
		
	}
	mysqli_close($conn);
 ?>

 