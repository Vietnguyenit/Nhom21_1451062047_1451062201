<html lang="vi" xmlns="http://www.w3.org/1999/xhtml">
<head>
    <title>Form validate</title>
    <meta http-equiv="Content-type" content="text/html; charset=utf-8" />
        <script src="js/jquery-1.12.2.min.js" type="text/javascript"></script>
        <script src="js/validate_jquery_plugin/jquery.validate.js" type="text/javascript"></script>
        <script src="js/common.js" type="text/javascript"></script>
        <link href="css/validate_jquery_plugin/screen.css" type="text/css" rel="stylesheet">
        <link href="css/styles.css" type="text/css" rel="stylesheet">
        <script>
            $(document).ready(function() {
                $("#email").blur(function(){
                    var e = $(this).val(); 
                    alert(e);

                    $.POST("register.php" , {email : e} , function(em){
                       alert (em);
                      // header("Location:http://www.google.com"); 

                       if(em == 0){
                            $("#mes").html("OK");
                         //   header("Location:http://www.google.com"); 
                       }else{
                            $("mes").html("NO");
                       }
                    });
                });
            });
        </script>
</head>
<body>
<div class="signup_form">
    <form name="signup_form" action="register.php" method="POST" id="signup_form">
        <div class="form_title">
            SignUp
        </div>
        <div>
            <label>First Name </label>
            <input class="input_text" name="ho" id="ho" placeholder="Ho">
        </div>
        <div>
            <label>Last Name </label>
            <input class="input_text" name="ten" id="ten" placeholder="Ten">
        </div>
        <div>
            <label>Sex</label>
            <input type="radio" checked="checked" name="sex" id="sex"/>Male
            <input type="radio" name="sex" id="sex"/>Female
        </div>
        <div>
            <label>Age</label>
            <select name="ages" id="ages">
                <script>
                    selectList(arr_ages, 'ages');
                </script>
            </select>
        </div>
         <div>
            <label>Email</label>
            <input class="input_text" name="email" id="email" placeholder="Email">
            <div id ="mes"></div>
        </div>
        <div>
            <label>Password</label>
            <input class="input_text" type="password" id="password" name="password" placeholder="Password">
        </div>
        <div>
            <label>Confirm Password</label>
            <input class="input_text" type="password" id="confirm_password" name="confirm_password" placeholder="Confirm Password">
        </div>
        <div class="btn_signup">
            <button type="submit">SignUP</button>
        </div>
    </form>
</div>
</body>
</html>
