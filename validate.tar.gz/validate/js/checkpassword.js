/*var password = document.getElementById("password")
  , confirm_password = document.getElementById("confirm_password");

function validatePassword(){
  if(password.value != confirm_password.value) {
    confirm_password.setCustomValidity("Passwords Don't Match");
  } else {
    confirm_password.setCustomValidity('');
  }
}

password.onchange = validatePassword;
confirm_password.onkeyup = validatePassword;*/

/*
<div class="container">
  <h1>Password Validation Test</h1>
  
  <ul>
    <li>Min 8 characters length</li>
    <li>One capital</li>
    <li>One lowercase</li>
    <li>One number</li>
  </ul>

  <form id="form">
    <div class="form-group">
      <label>Password</label>
      <input id="password" type="password" class="form-control" />
    </div>
    
    <div class="form-group">
      <label>Password Confirm</label>
      <input id="password-confirm" type="password" class="form-control" />
    </div>
    
    <button class="btn btn-primary" type="submit">Submit</button>
    
    <p id="message"></p>
  </form>
</div>*/

// validate.js regex method (format) is broken with complex regex expressions, custom version to fix it
validate.validators.regex = function(value, options, key, attributes) {
  let regExp = new RegExp(options.pattern);
  
  if (!regExp.test(value)) {
    return options.message;
  }
};

// Form submission and password validation
$('#form').submit((e) => {
  e.preventDefault();
  
  let pass = {
    pass: $('#password').val(),
    passConfirm: $('#password-confirm').val()
  };
  
  console.log('data', pass);
  
  let constraints = {
    pass: {
      presence: true,
      regex: {
        pattern: '(?=.*?[0-9])(?=.*?[A-Z])(?=.*?[a-z])',
        message: "Must contain a capital, lowercase, and number"
      },
      
      length: {
        minimum: 8
      }
    },
    
    passConfirm: {
      presence: true,
      equality: {
        attribute: "pass",
        message: "Passwords do not match",
        comparator: (v1, v2) => {
          return v1 === v2;
        }
      }
    }
  };

  let val = validate(pass, constraints);
  
  $('#message').html(JSON.stringify(val) || '');
});