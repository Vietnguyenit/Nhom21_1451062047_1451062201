/**
 * Created by root on 01/04/2016.
 */
var arr_countries = [
    'Afghanistan',
    'Albania',
    'Algeria',
    'Andorra',
    'Angola',
    'Antigua and Barbuda',
    'Argentina',
    'Armenia',
    'Aruba',
    'Australia',
    'Austria',
    'Azerbaijan'
];
var arr_ages = [10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30]


$.validator.addMethod("valueNotEquals", function(value, element, arg){
    return arg != value;
}, "Value must not equal arg.");

$.validator.addMethod("stringRegex", function(value, element) {
    return this.optional(element) || /^[a-z0-9\-]+$/i.test(value);
}, "Username must contain only letters, numbers, or dashes.");


function selectList(arr_data, selectId){
    var str = '<option value="default">--Select value--</option>';
    $.each(arr_data, function(i, e){
        str += '<option value="' + e + '">'+ e +'</option>';
    });
    $('#'+selectId).html(str);
}
$().ready(function() {

    $("#signup_form").validate({
        rules: {
            ho: {
                required: true,
                stringRegex: true,
                minlength: 3,
                maxlength: 10
            },
            ten: {
                required: true,
                stringRegex: true,
                minlength: 3,
                maxlength: 10
            },
            email: {
                required: true,
                email: true
            },
            ages: { valueNotEquals: "default" },
            countries: { valueNotEquals: "default" },

            password :{
                required:true,
                minlength:6
            },
            confirm_password:{
                required:true,
                minlength:6
              // equalTo: "#password"
            }
        },
        messages: {
            ho: {
                required: "Please enter first name !",
                stringRegex:"Can't container special characters !",
                minlength: "The first name more 3 characters!",
                maxlength: "The first name less 10 characters!"
            },
            ten: {
                required: " Enter the last name",
                stringRegex: "Can't container special characters !",
                minlength: "The last name more 3 characters!",
                maxlength: "The last name less 10 characters!"
            },
            email: {
                required: "Enter your email (abc@xyz) "
            },
            ages:{ 
                valueNotEquals: "Select Your age !" 
            },
            password: {
                required: "Please provide a password",
                minlength: "Your password must be at least 6 characters long"
            },
            confirm_password: {
                required: "Please provide a password",
                minlength: "Your password must be at least 6 characters long"
            }
        }
    });
});
