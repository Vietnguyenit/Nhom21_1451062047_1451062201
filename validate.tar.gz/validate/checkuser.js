$(document).ready(function(){
	$("name").blur(function(){
	val a = $(this).val();
	alert (a);
	});
});