﻿<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>ZingNews</title>
<!-- CSS -->
<link rel="stylesheet" href="http://stc.v3.news.zing.vn/css/styles_4.71_075.css" />
</head>


<body>

<header id="zingheader">
<div class="wrapper">
<hgroup>
<div class="logo"><a href="/" title="Zing News">Zing News - Tri thức trực tuyến</a></div>
</hgroup>
<form name="search" id="searchbox" class="znewsSearch">
<input type="text" value="Nhập nội dung cần tìm" onblur="if(this.value=='') this.value='Nhập nội dung cần tìm'" onfocus="if(this.value=='Nhập nội dung cần tìm') this.value=''" id="search_keyword">
<button type="submit" id="search_button">Tìm kiếm</button>
</form>

<ul class="apps">
<li class="mp3"><a href="http://mp3.zing.vn" title="Zing MP3" target="_blank">MP3</a></li>
<li class="tv"><a href="http://tv.zing.vn" title="Zing TV" target="_blank">TV</a></li>
<li class="me"><a href="http://me.zing.vn" title="Zing Me" target="_blank">ME</a></li>
</ul>
</header>

<div class="wrapper">
<header id="top">
<div id="site-header">
<div id="banner_top" class="banner">
<img src="http://media.adtimaserver.vn/2017/04/7ac82abc-af61-499e-b77f-bd6256e03cca.jpg" width="100%">
<div id="advTop"></div>
</div>
</div>
<nav class="categories">
<ul>
<li class="parent homepage current"><a href="/" title="Tin tức">Tin tức</a></li>
<!-- END MENU -->

<li class="parent thoi-su ">
<a>Thời sự</a>
<div class="subcate">
<ul>
<li><a>Giao thông</a></li> <li><a>Đô thị</a></li> <li><a>Đời sống</a></li> <li><a>Quốc phòng</a></li> <li><a>Ảnh & Video</a></li> 
</ul></div></li>

<li class="parent the-gioi ">
<a>Thế giới</a>
<div class="subcate">
<ul><li><a>Ảnh & Video</a></li> <li><a>Quân sự</a></li> <li><a>Tư liệu</a></li> <li><a>Phân tích</a></li> <li><a>Người Việt 4 phương</a></li> 
</ul></div></li>

<li class="parent kinh-doanh-tai-chinh ">
<a>Kinh doanh</a>
<div class="subcate">
<ul> <li><a>Tài chính</a></li> <li><a>Chứng khoán</a></li> <li><a>Bất động sản</a></li> <li><a>Doanh nhân</a></li> </ul></div></li>

<li class="parent phap-luat ">
<a>Pháp luật</a>
<div class="subcate">
<ul><li><a>Pháp đình</a></li> <li><a >Vụ án</a></li> </ul></div></li>

<li class="parent xuat-ban ">
<a>Xuất bản</a>
<div class="subcate">
<ul><li><a>Tin tức xuất bản</a></li> <li><a>Sách hay</a></li> <li><a>Tác giả</a></li> </ul></div></li>

<li class="parent the-thao ">
<a>Thể thao</a>
<div class="subcate">
<ul><li><a>Thể thao Việt Nam</a></li> <li><a>Cup Châu Âu</a></li> <li><a>Thể thao Thế giới</a></li> <li><a>Bóng đá</a></li> 
<li><a>Bóng đá Anh</a></li> <li><a>Bóng đá Việt Nam</a></li> <li><a>Bóng rổ</a></li> <li><a>Video bóng đá</a></li> 
<li><a >Hậu trường thể thao</a></li> </ul></div></li>

<li class="parent cong-nghe ">
<a>Công nghệ</a>
<div class="subcate">
<ul><li><a>Điện thoại</a></li> <li><a>Máy tính bảng</a></li> <li><a>Ứng dụng di động</a></li> </ul></div></li>

<li class="parent oto-xe-may ">
<a>Xe 360</a>
<div class="subcate">
<ul><li><a>Xe máy</a></li> <li><a >Ô-tô</a></li> <li><a>Xe độ</a></li> <li><a>Siêu xe</a></li> </ul></div></li>

<li class="parent giai-tri ">
<a>Giải trí</a>
<div class="subcate">
<ul><li><a>Sao Việt</a></li> <li><a>Sao Châu Á</a></li> <li><a>Sao Hollywood</a></li> </ul></div></li>

<li class="parent am-nhac ">
<a>Âm nhạc</a>
<div class="subcate">
<ul><li><a>Nhạc Việt</a></li> <li><a>Nhạc Hàn</a></li> <li><a>Nhạc Âu Mỹ</a></li> </ul></div></li>

<li class="parent phim-anh ">
<a>Phim ảnh</a>
<div class="subcate">
<ul><li><a>Phim chiếu rạp</a></li> <li><a>Phim truyền hình</a></li> <li><a>Game Show</a></li> </ul></div></li>

<li class="parent thoi-trang ">
<a>Thời trang</a>
<div class="subcate">
<ul><li><a>Thời trang sao</a></li> <li><a>Mặc đẹp</a></li> <li><a>Làm đẹp</a></li> </ul></div></li>

<li class="parent song-tre ">
<a>Sống trẻ</a>
<div class="subcate">
<ul><li><a>Gương mặt trẻ</a></li> <li><a>Cộng đồng mạng</a></li> <li><a>Sự kiện</a></li> </ul></div></li>

<li class="parent giao-duc ">
<a>Giáo dục</a>
<div class="subcate">
<ul><li><a>Tuyển sinh 2017</a></li> <li><a>Tư vấn</a></li> <li><a>Du học</a></li> </ul></div></li>

<li class="parent suc-khoe ">
<a>Sức khỏe</a>
<div class="subcate">
<ul><li><a>Khỏe đẹp</a></li> <li><a>Dinh dưỡng</a></li> <li><a>Mẹ và Bé</a></li> <li><a>Bệnh thường gặp</a></li> </ul></div></li>

<li class="parent du-lich ">
<a>Du lịch</a>
<div class="subcate">
<ul><li><a>Địa điểm du lịch</a></li> <li><a>Kinh nghiệm du lịch</a></li> <li><a>Phượt</a></li> </ul></div></li>

<li class="parent am-thuc ">
<a>Ẩm thực</a>
<div class="subcate">
<ul><li><a>Địa điểm ăn uống</a></li> <li><a>Món ngon</a></li> </ul></div></li>

<li class="parent nhip-song ">
<a>Nhịp sống</a>
<div class="subcate">
<ul><li><a>Thông tin doanh nghiệp</a></li> <li><a>Cười</a></li> </ul></div></li>
</ul>
</nav>
</header>



<!-- section 1: nam ben tay trai -->
<section id="homepage" class="focus_layout">
<div class="content-wrap">
<div class="hotnews">
<p class="controller">
<a href="#rewind" class="rewind">Trước</a>
<a href="#forward" class="forward">Sau</a>
</p>
<h1>Tin tức mới</h1>
<ul>
</ul>
<time datetime="2017-05-09 22:14+0700" pubdate>Cập nhật </time>
</div>
<section class="featured">

<article class="featured infographic" topic-id="2000,2369">
<p class="type"></p>
<a href="Zing.php"><div class="cover">
<img src="http://znews-photo-td.zadn.vn/w660/Uploaded/aohunkx/2017_04_21/HAGL_thumb.jpg" alt="Toan canh &#39;de che&#39; Hoang Anh Gia Lai cua bau Duc hinh anh" title="Toàn cảnh &#39;đế chế&#39; Hoàng Anh Gia Lai của bầu Đức hình ảnh">
</div></a>
<header>
<a href="Zing.php"><p class="title">Toàn cảnh 'đế chế' Hoàng Anh Gia Lai của bầu Đức</p></a>
<time datetime="2017-05-09 15:25+0700"></time>
<p class="cate">Kinh doanh</p>
<p class="summary">Năm 2016, hơn một nửa doanh thu của Hoàng Anh Gia Lai đến từ đàn bò, lỗ ròng 1.503 tỷ đồng. Đầu năm 2017, hàng chục nghìn tỷ đồng nợ vay của công ty đã được giãn nợ 3-5 năm.</p>
</header>

<ul class="relate">
<li class=" infographic">
<a>Toàn cảnh sức khỏe 'hãng hàng không bikini</a></li>
</ul>
</article>

<article class="" topic-id="426,2000">
<p class="type"></p>
<div class="cover">
<img src="http://znews-photo-td.zadn.vn/w210/Uploaded/ngtmns/2017_05_09/Picture_Sleeping_pilot.jpeg" alt="Phi cong co duoc phep ngu khi may bay dang o tren troi? hinh anh" title="Phi công có được phép ngủ khi máy bay đang ở trên trời? hình ảnh">
</div>
<header>
<p class="title">
<a>Phi công có được phép ngủ khi máy bay đang ở trên trời?</a></p>
<time datetime="2017-05-09 20:00+0700"></time>
<p class="cate">Du lịch</p>
</header>
</article>


<article class="" topic-id="426,2000">
<p class="type"></p>
<div class="cover">
<img src="http://znews-photo-td.zadn.vn/w210/Uploaded/ngtmns/2017_05_09/Picture_Sleeping_pilot.jpeg" alt="Phi cong co duoc phep ngu khi may bay dang o tren troi? hinh anh" title="Phi công có được phép ngủ khi máy bay đang ở trên trời? hình ảnh">
</div>
<header>
<p class="title">
<a>Phi công có được phép ngủ khi máy bay đang ở trên trời?</a></p>
<time datetime="2017-05-09 20:00+0700"></time>
<p class="cate">Du lịch</p>
</header>
</article>

<article class=" hasvideo" topic-id="2000,2369">
<p class="type"></p>
<div class="cover">
<img src="http://znews-photo-td.zadn.vn/w210/Uploaded/znguhv/2017_05_09/zing_jaein.JPG" alt="Ong Moon Jae In tuyen bo thang cu tong thong Han Quoc hinh anh" title="Ông Moon Jae In tuyên bố thắng cử tổng thống Hàn Quốc hình ảnh">
</div>
<header>
<p class="title">
<a>Ông Moon Jae In tuyên bố thắng cử tổng thống Hàn Quốc</a></p>
<time datetime="2017-05-09 18:15+0700"></time>
<p class="cate">Thế giới</p>
</header>
</article>
</section>



<!-- section 2: canh ben phai section 1 -->
<section class="trending scroll">
<div class="top-list">
<article class="" topic-id="2001,2369">
<p class="type"></p>
<div class="cover">
<img src="http://znews-photo-td.zadn.vn/w210/Uploaded/iutmtn/2017_05_09/xoi_1.jpg" alt="Chu hang xoi doanh thu 60 trieu dong/ngay len tieng chuyen dong cua hinh anh" title="Chủ hàng xôi doanh thu 60 triệu đồng/ngày lên tiếng chuyện đóng cửa hình ảnh">
</div>
<header>
<p class="title">
<a>Chủ hàng xôi doanh thu 60 triệu đồng/ngày lên tiếng chuyện đóng cửa</a>
<span class="comment_count">55</span></p>
<time datetime="2017-05-09 18:06+0700"></time>
<p class="cate">Kinh doanh</p>
</header>
</article>
</div>

<article class=" picture" topic-id="2001,2369">
<p class="type"></p>
<header>
<p class="title">
<a>Diễn viên 'Em chưa 18' tình tứ bên bạn trai ở sự kiện</a>
<span class="social hot">HOT</span>
<span class="comment_count">5</span></p>
<time datetime="2017-05-09 21:52+0700"></time>
<p class="cate">Sao Việt</p>
</header>
</article>

<article class=" hasvideo" topic-id="2001,2369">
<p class="type"></p>
<header>
<p class="title">
<a>Phái Nam Huỳnh Đạo trả lời tin đồn thách đấu Từ Hiểu Đông</a>
<span class="social hot">HOT</span>
<span class="comment_count">23</span></p>
<time datetime="2017-05-09 20:03+0700"></time>
<p class="cate">Thể thao Việt Nam</p>
</header>
</article>

<article class="" topic-id="2001,2218">
<p class="type"></p>
<header>
<p class="title">
<a>Chém chết kẻ trộm sầu riêng, thanh niên uống thuốc tự tử</a></p>
<time datetime="2017-05-09 21:43+0700"></time>
<p class="cate">Pháp luật</p>
</header>
</article>

<article class=" hasvideo" topic-id="2001,2369">
<p class="type"></p>
<header>
<p class="title">
<a>Lý Liên Kiệt và dàn sao võ thuật thua chắc trước võ sư MMA</a>
<span class="social hot">HOT</span>
<span class="comment_count">32</span></p>
<time datetime="2017-05-09 18:23+0700"></time>
<p class="cate">Sao Châu Á</p>
</header>
</article>

<article class="" topic-id="2001,2249,2369">
<p class="type"></p>
<header>
<p class="title">
<a>Nam thanh niên cầm dao phay dọa chém nhân viên bệnh viện</a></p>
<time datetime="2017-05-09 21:02+0700"></time>
<p class="cate">Pháp luật</p>
</header>
</article>

<article class="" topic-id="2001,2246,2369">
<p class="type"></p>
<header>
<p class="title">
<a>Ba người bị sét đánh tử vong khi đào mộ chôn người chết</a>
<span class="social hot">HOT</span></p>
<time datetime="2017-05-09 18:58+0700"></time>
<p class="cate">Thời sự</p>
</header>
</article>

<article class=" picture hasvideo" topic-id="2001,2208,2369">
<p class="type"></p>
<header>
<p class="title">
<a>Tuấn Anh, Công Phượng bất lực trước đội hạng Nhất Viettel</a>
<span class="comment_count">9</span></p>
<time datetime="2017-05-09 20:01+0700"></time>
<p class="cate">Bóng đá Việt Nam</p>
</header>
</article>

<article class=" hasvideo" topic-id="2001,2369">
<p class="type"></p>
<header>
<p class="title">
<a>Nghi vấn Từ Hiểu Đông 'đánh trống bỏ dùi' sau ồn ào thách đấu</a></p>
<time datetime="2017-05-09 20:22+0700"></time>
<p class="cate">Thế giới</p>
</header>
</article>

<script>
var elements = $('.top-list article').length;
$($('.top-list article')[Math.floor(Math.random() * elements)]).show();
</script>
</section>
</div>



<!-- section 3 : Quang cao -->
<section class="sidebar">
<div id="advR1" class="banner"></div>
<div id="advR2" class="banner"></div>
<div class="contact">
<ul>
<li class="email">
<span>Email</span>
<a title="Gửi email">toasoan@zing.vn</a> | <a title="Liên hệ quảng cáo">Liên hệ Quảng cáo</a>
</li>
<li class="phone">
<span>Đường dây nóng</span>
<a title="Điện thoại nóng">(HN) 0985.57.88.55</a> | <a title="Điện thoại nóng">(HCM) 0909.18.66.66</a>
</li>
</ul>
</div>
</section>



<!-- section 4: Anh va video -->
<section id="multimedia">
<header>
<h2>Ảnh và video</h2>
</header>
<article class=" picture hasvideo" topic-id="2002,2208,2369">
<p class="type"></p>
<div class="cover">
<a><img src="http://znews-photo-td.zadn.vn/w210/Uploaded/natmrb/2017_05_08/9.jpg" alt="Can canh noi &#39;an choi noi loan&#39; moi mo danh cho gioi sanh dieu hinh anh" title="Cận cảnh nơi &#39;ăn chơi nổi loạn&#39; mới mở dành cho giới sành điệu hình ảnh"></a> </div>
<header>
<p class="title">
<a>Cận cảnh nơi 'ăn chơi nổi loạn' mới mở dành cho giới sành điệu</a></p>
<time datetime="2017-05-09 18:31+0700"></time>
<p class="cate">Sống trẻ</p>
</header>
</article>

<article class=" picture hasvideo" topic-id="2002,2003">
<p class="type"></p>
<div class="cover">
<a><img src="http://znews-photo-td.zadn.vn/w210/Uploaded/bpmoqwq1/2017_05_09/zing_parade_12.jpg" alt="Nga khoe ten lua phong khong Bac Cuc tai le dieu binh hinh anh" title="Nga khoe tên lửa phòng không Bắc Cực tại lễ diễu binh hình ảnh"></a></div>
<header>
<p class="title">
<a>Nga khoe tên lửa phòng không Bắc Cực tại lễ diễu binh</a></p>
<time datetime="2017-05-09 16:20+0700"></time>
<p class="cate">Quân sự</p>
</header>
</article>

<article class=" picture" topic-id="2002">
<p class="type"></p>
<div class="cover">
<a><img src="http://znews-photo-td.zadn.vn/w210/Uploaded/Yfrur/2017_05_09/12.jpg" alt="Nam ung vien sang gia o Hoa hau Hoan vu Viet Nam 2017 hinh anh" title="Năm ứng viên sáng giá ở Hoa hậu Hoàn vũ Việt Nam 2017 hình ảnh"></a></div>
<header>
<p class="title">
<a>Năm ứng viên sáng giá ở Hoa hậu Hoàn vũ Việt Nam 2017</a>
<span class="social hot">HOT</span>
<span class="comment_count">17</span>
</p>
<time datetime="2017-05-09 13:49+0700"></time>
<p class="cate">Thời trang sao</p>
</header>
</article>

<article class=" picture" topic-id="2002,2003">
<p class="type"></p>
<div class="cover">
<a><img src="http://znews-photo-td.zadn.vn/w210/Uploaded/xbhunua/2017_05_09/7788899.jpg" alt="Ronaldo va ban gai nong bong trong ky nghi ngan ngay hinh anh" title="Ronaldo và bạn gái nóng bỏng trong kỳ nghỉ ngắn ngày hình ảnh"></a></div>
<header>
<p class="title">
<a>Ronaldo và bạn gái nóng bỏng trong kỳ nghỉ ngắn ngày</a>
<span class="social hot">HOT</span>
<span class="comment_count">6</span>
</p>
<time datetime="2017-05-09 13:46+0700"></time>
<p class="cate">Hậu trường thể thao</p>
</header>
</article>

<article class=" picture" topic-id="2002,2003,2008">
<p class="type"></p>
<div class="cover">
<a><img src="http://znews-photo-td.zadn.vn/w210/Uploaded/cqxrcajwp/2017_05_09/j0.jpg" alt="Sao Viet chung minh ao tam lien manh moi la mot hinh anh" title="Sao Việt chứng minh áo tắm liền mảnh mới là mốt hình ảnh"></a></div>
<header>
<p class="title">
<a>Sao Việt chứng minh áo tắm liền mảnh mới là mốt</a>
<span class="comment_count">18</span>
</p>
<time datetime="2017-05-09 07:56+0700"></time>
<p class="cate">Thời trang sao</p>
</header>
</article>
</section>

<div class="content-wrap">
<div class="content-wrap">



<!-- section 5: Thoi su -->
<section id="thoi-su" class="category skin1">
<header>
<hgroup>
<h2><a href="/thoi-su.html" title="Thời sự">Thời sự </a></h2>
</hgroup>
<p><a href='/giao-thong.html'>
<p><a href='/do-thi.html'>Đô thị</a></p>
<p><a href='/doi-song.html'>Đời sống</a></p>
<p><a href='/quoc-phong.html'>Quốc phòng</a></p>
<p><a href='/anh-video-thoi-su.html'>Ảnh & Video</a></p>
</header>

<article class="featured hasvideo haschart" topic-id="2208">
<p class="type"></p>
<header>
<p class="title">
<a>'Nhiều người dân bỏ phương tiện cá nhân để đi BRT'</a></p>
<time datetime="2017-05-09 19:41+0700"></time>
</header>
<div class="cover">
<a><img src="http://znews-photo-td.zadn.vn/w210/Uploaded/kpcwvovd/2017_05_09/buyt_5_zing.jpg" alt="&#39;Nhieu nguoi dan bo phuong tien ca nhan de di BRT&#39; hinh anh" title="&#39;Nhiều người dân bỏ phương tiện cá nhân để đi BRT&#39; hình ảnh"></a>&nbsp;</div>
<p class="summary">Giám đốc Trung tâm quản lý giao thông đô thị Hà Nội khẳng định 23% người dân từ bỏ phương tiện cá nhân để đi buýt nhanh sau 5 tháng hoạt động.</p>
<ul class="relate">
<li class=" picture">
<a>Nội thất đơn giản của buýt nhanh BRT bị tố đội giá</a></li>
</ul>
</article>

<div class="top">
<article class="" topic-id="2221">
<header>
<p class="title">
<a>'Tự nguyện' nộp 2 triệu đồng khi sinh con thứ 3 mới có giấy khai sinh</a></p>
<time datetime="2017-05-10 00:01+0700"></time>
</header>
</article>

<article class="" topic-id="2209">
<header>
<p class="title">
<a>Tặng bằng khen cho nữ nhân viên trả lại 1 tỷ đồng</a></p>
<time datetime="2017-05-09 20:17+0700"></time>
</header>
</article>

<article class="" topic-id="2001,2246,2369">
<header>
<p class="title">
<a>Ba người bị sét đánh tử vong khi đào mộ chôn người chết</a>
<span class="social hot">HOT</span></p>
<time datetime="2017-05-09 18:58+0700"></time>
</header>
</article>

<article class="" topic-id="2000,2369">
<header>
<p class="title">
<a>Trung ương thảo luận về kết quả kiểm điểm sự lãnh đạo của Bộ Chính trị</a></p>
<time datetime="2017-05-09 17:25+0700"></time>
</header>
</article>
</div>

<article class="aside haschart" topic-id="2223">
<p class="type"></p>
<div class="cover">
<a><img src="http://znews-photo-td.zadn.vn/w120/Uploaded/rohunuk/2017_05_09/khai_thac_cat.jpg" alt="Cong an Phu Quoc tu y khai thac cat duoi song Duong Dong hinh anh" title="Công an Phú Quốc tự ý khai thác cát dưới sông Dương Đông hình ảnh"></a>&nbsp;</div>
<header>
<p class="title">
<a>Công an Phú Quốc tự ý khai thác cát dưới sông Dương Đông</a>
<span class="social hot">HOT</span><span class="comment_count">6</span></p>
<time datetime="2017-05-09 16:35+0700"></time>
</header>
</article>
</section>



<!-- section 6: The gioi -->
<section id="the-gioi" class="category skin1">
<header>
<hgroup>
<h2><a title="Thế giới">Thế giới </a></h2>
</hgroup>
<p><a>Ảnh & Video</a></p>
<p><a>Quân sự</a></p>
<p><a>Tư liệu</a></p>
<p><a>Phân tích</a></p>
<p><a>Người Việt 4 phương</a></p>
</header>

<article class="featured hasvideo" topic-id="2000,2369">
<p class="type"></p>
<header>
<p class="title">
<a>Trump gây sốc khi bất ngờ sa thải giám đốc FBI</a></p>
<time datetime="2017-05-10 06:01+0700"></time>
</header>
<div class="cover">
<a><img src="http://znews-photo-td.zadn.vn/w210/Uploaded/sgtnrb/2017_05_10/150723jamescomeyjpo500a_18fedec20ffef3fb4226c7fdced44951nbcnewsfp1200800.jpg" alt="Trump gay soc khi bat ngo sa thai giam doc FBI hinh anh" title="Trump gây sốc khi bất ngờ sa thải giám đốc FBI hình ảnh"></a>&nbsp;</div>
<p class="summary">Giám đốc FBI James Comey, người từng tạo ra "bất ngờ tháng 10" bị Hillary Clinton cáo buộc góp phần khiến bà thất bại trong bầu cử Mỹ, đã bị sa thải.</p>
<ul class="relate">
<li class=" hasvideo">
<a>Clinton: Nếu bầu cử diễn ra vào 27/10, tôi sẽ là tổng thống</a></li></ul>
</article>

<div class="top">
<article class=" hasvideo" >
<header>
<p class="title">
<a>Giám đốc FBI biết tin bị sa thải qua TV</a></p>
<time datetime="2017-05-10 08:07+0700"></time>
</header>
</article>

<article class=" hasvideo" topic-id="2000,2369">
<header>
<p class="title">
<a>Khi người con của Triều Tiên trở thành tổng thống Hàn Quốc</a>
<span class="social hot">HOT</span></p>
<time datetime="2017-05-10 05:01+0700"></time>
</header>
</article>

<article class="" >
<header>
<p class="title">
<a>Nga bác tin quân nhân bị IS chặt đầu ở Syria</a></p>
<time datetime="2017-05-09 21:45+0700"></time>
</header>
</article>

<article class=" picture hasvideo" >
<header>
<p class="title">
<a>Obama xuất hiện đầy phong cách ở kinh đô thời trang Milan</a>
<span class="social hot">HOT</span></p>
<time datetime="2017-05-09 21:13+0700"></time>
</header>
</article>
</div>

<article class="aside video" >
<p class="type"></p>
<div class="cover">
<a><img src="http://znews-photo-td.zadn.vn/w120/Uploaded/sgtnrb/2017_05_09/xiaodong_thumb.jpg" alt="Tu Hieu Dong se tu bo thach dau? hinh anh" title="Từ Hiểu Đông sẽ từ bỏ thách đấu? hình ảnh"></a>&nbsp;</div>
<header>
<p class="title">
<a>Từ Hiểu Đông sẽ từ bỏ thách đấu?</a></p>
<time datetime="2017-05-10 07:13+0700"></time>
</header>
</article>
</section>



<!-- section 7: Kinh doanh -->
<section id="kinh-doanh" class="category skin1">
<header>
<hgroup>
<h2><a title="Kinh doanh">Kinh doanh </a></h2>
</hgroup>
<p><a>Tài chính</a></p>
<p><a>Chứng khoán</a></p>
<p><a>Bất động sản</a></p>
<p><a>Doanh nhân</a></p>
</header>

<article class="featured " topic-id="2001">
<p class="type"></p>
<header>
<p class="title">
<a>Chủ hàng xôi doanh thu 60 triệu đồng/ngày lên tiếng chuyện đóng cửa</a>
<span class="comment_count">56</span></p>
<time datetime="2017-05-09 18:06+0700"></time>
</header>
<div class="cover">
<a><img src="http://znews-photo-td.zadn.vn/w210/Uploaded/iutmtn/2017_05_09/xoi_1.jpg" alt="Chu hang xoi doanh thu 60 trieu dong/ngay len tieng chuyen dong cua hinh anh" title="Chủ hàng xôi doanh thu 60 triệu đồng/ngày lên tiếng chuyện đóng cửa hình ảnh"></a>&nbsp;</div>
<p class="summary">Chủ hàng xôi Yến khẳng định quán chỉ đóng cửa tạm thời trong một thời gian ngắn sau đó sẽ hoạt động lại, không như tin đồn một số người đưa ra. </p>
<ul class="relate">
<li class="">
<a>Bí quyết của những hàng ăn doanh thu vài chục triệu/ngày kiểu xôi Yến </a></li></ul>
</article>

<div class="top">
<article class="" >
<header>
<p class="title">
<a>Xe ôm 4k' của sinh viên ở Sài Gòn</a></p>
<time datetime="2017-05-10 08:14+0700"></time>
</header>
</article>

<article class="" >
<header>
<p class="title">
<a>Startup lớn nhất Đông Nam Á đổi tên sau khi nhận 550 triệu USD đầu tư</a></p>
<time datetime="2017-05-10 07:54+0700"></time>
</header>
</article>

<article class=" hasvideo" >
<header>
<p class="title">
<a>Kiểm tra khẩn đa cấp Nhã Khắc Lâm</a></p>
<time datetime="2017-05-09 16:32+0700"></time>
</header>
</article>

<article class=" infographic" topic-id="2000,2002">
<header>
<p class="title">
<a>Toàn cảnh 'đế chế' Hoàng Anh Gia Lai của bầu Đức</a></p>
<time datetime="2017-05-09 15:25+0700"></time>
</header>
</article>
</div>

<article class="aside " topic-id="2210">
<p class="type"></p>
<div class="cover">
<a><img src="http://znews-photo-td.zadn.vn/w120/Uploaded/mfzhr/2017_05_09/DSC_2032.JPG" alt="Mot tuan, Dong Nai giai cuu gan 140 tan thit heo hinh anh" title="Một tuần, Đồng Nai giải cứu gần 140 tấn thịt heo hình ảnh"></a>&nbsp;</div>
<header>
<p class="title">
<a>Một tuần, Đồng Nai giải cứu gần 140 tấn thịt heo</a></p>
<time datetime="2017-05-09 20:34+0700"></time>
</header>
</article>
</section>



<!-- section 8: Phap luat -->
<section id="phap-luat" class="category skin1">
<header>
<hgroup>
<h2><a title="Pháp luật">Pháp luật </a></h2>
</hgroup>
<p><a>Pháp đình</a></p>
<p><a>Vụ án</a></p>
</header>

<article class="featured " topic-id="2001,2212,2369">
<p class="type"></p>
<header>
<p class="title">
<a>Vụ công an xã đánh chết học sinh lớp 9: 'Chúng tôi mệt mỏi lắm rồi'</a>
<span class="social hot">HOT</span><span class="comment_count">9</span></p>
<time datetime="2017-05-10 07:20+0700"></time>
</header>
<div class="cover">
<a><img src="http://znews-photo-td.zadn.vn/w210/Uploaded/nugzrd/2017_05_09/H2.jpg" alt="Vu cong an xa danh chet hoc sinh lop 9: &#39;Chung toi met moi lam roi&#39; hinh anh" title="Vụ công an xã đánh chết học sinh lớp 9: &#39;Chúng tôi mệt mỏi lắm rồi&#39; hình ảnh"></a>&nbsp;</div>
<p class="summary">Nói trước tòa, cha mẹ em Tu Ngọc Thạch (học sinh lớp 9) bị đánh chết mong tòa xét xử công bằng, không lọt tội. Họ nói mỗi lần ra tòa lại nhớ đến người đã khuất, chịu không nổi.</p>
<ul class="relate">
<li class="">
<a>Điều tra lại vụ án công an xã đánh chết học sinh</a></li></ul>
</article>

<div class="top">
<article class="" topic-id="2001,2220">
<header>
<p class="title">
<a>Ông Nén nói về việc chi tiêu hơn 10 tỷ tiền bồi thường</a></p>
<time datetime="2017-05-10 09:10+0700"></time>
</header>
</article>

<article class="" >
<header>
<p class="title">
<a href="/ten-dau-so-bang-cuop-chuyen-cai-trang-phu-nu-linh-22-nam-tu-post744802.html">
Tên đầu sỏ băng cướp chuyên cải trang phụ nữ lĩnh 22 năm tù</a></p>
<time datetime="2017-05-10 08:02+0700"></time>
</header>
</article>

<article class="" topic-id="2218">
<header>
<p class="title">
<a>Chém chết kẻ trộm sầu riêng, thanh niên uống thuốc tự tử</a>
<span class="comment_count">5</span></p>
<time datetime="2017-05-09 21:43+0700"></time>
</header>
</article>

<article class="" topic-id="2249">
<header>
<p class="title">
<a>Nam thanh niên cầm dao phay dọa chém nhân viên bệnh viện</a></p>
<time datetime="2017-05-09 21:02+0700"></time>
</header>
</article>

</div>
<article class="aside video hasvideo" topic-id="2208">
<p class="type"></p>
<div class="cover">
<a><img src="http://znews-photo-td.zadn.vn/w120/Uploaded/fsmqv/2017_05_09/Nguyen_Xuan_Ve.jpg" alt="Thieu nu 16 tuoi can ke doi cuong hiep de thoat than hinh anh" title="Thiếu nữ 16 tuổi cắn kẻ đòi cưỡng hiếp để thoát thân hình ảnh"></a>&nbsp;</div>
<header>
<p class="title">
<a>Thiếu nữ 16 tuổi cắn kẻ đòi cưỡng hiếp để thoát thân</a></p>
<time datetime="2017-05-10 07:27+0700"></time>
</header>
</article>
</section>



<!-- section 9: Xuat ban -->
<section id="xuat-ban" class="category skin1">
<header>
<hgroup>
<h2><a title="Xuất bản">Xuất bản </a></h2>
</hgroup>
<p><a>Tin tức xuất bản</a></p>
<p><a>Sách hay</a></p>
<p><a>Tác giả</a></p>
</header>
<article class="featured " >
<p class="type"></p>
<header>
<p class="title">
<a>'Bàn về chính quyền' - tác phẩm chính trị quan trọng của Cicero</a></p>'
<time datetime="2017-05-10 06:26+0700"></time>
</header>
<div class="cover">
<a><img src="http://znews-photo-td.zadn.vn/w210/Uploaded/neg_iflemly/2017_05_09/Bia_Ban_ve_chinh_quyen_thumb.jpg" alt="&#39;Ban ve chinh quyen&#39; - tac pham chinh tri quan trong cua Cicero hinh anh" title="&#39;Bàn về chính quyền&#39; - tác phẩm chính trị quan trọng của Cicero hình ảnh"></a>&nbsp;</div>
<p class="summary">"Bàn về chính quyền" của Cicero luôn được coi là một trong những nền tảng tư tưởng quan trọng của phương Tây.</p>
<ul class="relate">
<li class="">
<a>J.K. Rowling xin lỗi người hâm mộ về cái chết của Severus Snape</a></li></ul>
</article>

<div class="top">
<article class="" >
<header>
<p class="title">
<a>'Tớ nên tin vào điều gì?': Lòng tin là cội nguồn của hạnh phúc</a></p>
<time datetime="2017-05-09 13:34+0700"></time>
</header>
</article>

<article class="" >
<header>
<p class="title">
<a>Những tín hiệu vui từ hội nghị của Hiệp hội Xuất bản ASEAN</a></p>
<time datetime="2017-05-09 10:40+0700"></time>
</header>
</article>

<article class="" >
<header>
<p class="title">
<a>Cuốn sách giúp ta sống hướng thiện và tử tế</a></p>
<time datetime="2017-05-09 06:37+0700"></time>
</header>
</article>

<article class="" >
<header>
<p class="title">
<a>'Cô gái Brooklyn': Cuộc truy hồi gay cấn từ ký ức</a></p>
<time datetime="2017-05-08 18:00+0700"></time>
</header>
</article>

</div>
<article class="aside " >
<p class="type"></p>
<div class="cover">
<a><img src="http://znews-photo-td.zadn.vn/w120/Uploaded/neg_iflemly/2017_05_07/trc6b0c6a1ngkimc491e1bb8bnh_thumb.jpg" alt="Tai ban bo sach triet ly an vi cua Kim Dinh hinh anh" title="Tái bản bộ sách triết lý an vi của Kim Định hình ảnh"></a>&nbsp;</div>
<header>
<p class="title">
<a>Tái bản bộ sách triết lý an vi của Kim Định</a></p>
<time datetime="2017-05-09 17:00+0700"></time>
</header>
</article>
</section>



<!-- section 10: The thao -->
<section id="the-thao" class="category skin2">
<header>
<hgroup>
<h2><a title="Thể thao">Thể thao </a></h2>
<p><a>Thể thao Việt Nam</a></p>
<p><a>Cup Châu Âu</a></p>
<p><a>Thể thao Thế giới</a></p>
<p><a>Bóng đá</a></p>
<p><a>Bóng đá Anh</a></p>
<p><a>Bóng đá Việt Nam</a></p>
<p><a>Bóng rổ</a></p>
<p><a>Video bóng đá</a></p>
<p><a>Hậu trường thể thao</a></p>
</hgroup>
</header>

<article class="featured hasvideo" topic-id="2001,2369">
<div class="cover">
<a><img src="http://znews-photo-td.zadn.vn/w480/Uploaded/Aohuoia/2017_05_10/g_6.jpg" alt="Cung Le da cho nha vo dich vo thuat Trung Quoc that bai nhu the nao? hinh anh" title="Cung Lê đã cho nhà vô địch võ thuật Trung Quốc thất bại như thế nào? hình ảnh"></a></div>
<header>
<p class="title">
<a>Cung Lê đã cho nhà vô địch võ thuật Trung Quốc thất bại như thế nào?</a></p>
<time datetime="2017-05-10 09:20+0700"></time>
</header>
<p class="summary">Mới đây, Cung Lê đã gửi lời thách đấu đến võ sĩ ngông cuồng Từ Hiểu Đông. Trong quá khứ, võ sĩ gốc Việt từng đánh bại một võ sĩ còn tên tuổi hơn tay đấm họ Từ rất nhiều.</p>
</article>
<div class="top">
<article class="" topic-id="2001">
<div class="cover">
<a><img src="http://znews-photo-td.zadn.vn/w210/Uploaded/BzcwvoBL/2017_05_10/20170509T193808Z_137360288_MT1ACI14791014_RTRMADP_3_SOCCERCHAMPIONSJUVAMO.JPG" alt="Voi Dani Alves, Juventus tim thay &#39;Messi 0 dong&#39; hinh anh" title="Với Dani Alves, Juventus tìm thấy &#39;Messi 0 đồng&#39; hình ảnh"></a></div>
<header>
<p class="title">
<a>Với Dani Alves, Juventus tìm thấy 'Messi 0 đồng'</a></p>
</header>
<p class="summary">Pep Guardiola từng nói: "Chúng tôi từng vô địch Champions League với 8 cầu thủ của lò La Masia. Đội bóng chẳng tốn đồng nào cả". Đêm qua, Juventus tìm thấy một món quà giá 0 đồng.</p>
</article>

<article class=" stream hasvideo" topic-id="2001,2369">
<div class="cover">
<a><img src="http://znews-photo-td.zadn.vn/w210/Uploaded/SgtnRN/2017_05_09/buffon3.jpg" alt="Juve vao chung ket Champions League voi ty so chung cuoc 4-1 hinh anh" title="Juve vào chung kết Champions League với tỷ số chung cuộc 4-1 hình ảnh"></a></div>
<header>
<p class="title">
<a>Juve vào chung kết Champions League với tỷ số chung cuộc 4-1</a></p>
</header>
<p class="summary">Đánh bại AS Monaco 2-1 ở lượt về bán kết diễn ra trên sân nhà lúc 1h45, Juve vào chung kết Champions League khi giành chiến thắng chung cuộc 4-1 sau 2 lượt trận.</p>
</article>

<article class=" picture" >
<header>
<p class="title">
<a>Cựu sao bóng đá lột xác đầy cơ bắp</a></p>
</header>
<p class="summary">Sau khi giã từ nghiệp quần đùi áo số, tiền đạo Jose Mari chọn con đường thay đổi ngoại hình bản thân bằng việc tập luyện miệt mài trong phòng gym.</p>
</article>

<article class="" >
<header>
<p class="title">
<a>Mahrez đề nghị Leicester bán mình cho đại gia</a></p>
</header>
<p class="summary">Ngôi sao Riyad Mahrez hy vọng Leicester City sẽ để anh đến một đội bóng lớn sau khi mùa 2016/17 kết thúc.</p>
</article>

<article class="" topic-id="2001">
<header>
<p class="title">
<a>FIFA điều tra khẩn thương vụ MU mua Pogba</a></p>
</header>
<p class="summary">Thương vụ đắt giá nhất thế giới của đội chủ sân Old Trafford trở thành mục tiêu điều tra sau những cáo buộc sai phạm.</p>
</article>

<article class=" hasvideo" >
<header>
<p class="title">
<a>'Ai cản được Ronaldo giành Quả bóng vàng?'</a></p>
</header>
<p class="summary">Phải còn lâu gala trao giải Quả bóng vàng 2018 mới diễn ra, nhưng ngay lúc này, chủ nhân giải thưởng danh giá sớm lộ diện.</p>
</article>
</div>
</section>



<!-- section 11: Cong nghe -->
<section id="cong-nghe" class="category skin1">
<header>
<hgroup>
<h2><a title="Công nghệ">Công nghệ </a></h2>
</hgroup>
<p><a>Điện thoại</a></p>
<p><a>Máy tính bảng</a></p>
<p><a>Ứng dụng di động</a></p>
</header>

<article class="featured picture" >
<p class="type"></p>
<header>
<p class="title">
<a>Ảnh dựng phác họa từng chi tiết iPhone 8</a></p>
<time datetime="2017-05-10 08:28+0700"></time>
</header>
<div class="cover">
<a><img src="http://znews-photo-td.zadn.vn/w210/Uploaded/Aohuouk/2017_05_10/AllegediPhone8renders_4.jpg" alt="Anh dung phac hoa tung chi tiet iPhone 8 hinh anh" title="Ảnh dựng phác họa từng chi tiết iPhone 8 hình ảnh"></a>&nbsp;</div>
<p class="summary">Hình ảnh dựng lên từ bản vẽ CAD của iPhone 8 rò rỉ trước đây. Máy khá dày, thiết kế bo cong hoàn mĩ.</p>
<ul class="relate">
<li class=" hasvideo">
<a>Apple là công ty đầu tiên được định giá 800 tỷ USD</a></li></ul>
</article>
<div class="top">
<article class="" >
<header>
<p class="title">
<a>Facebook mạnh tay xử lý nội dung trái phép tại Thái Lan</a></p>
<time datetime="2017-05-10 09:54+0700"></time>
</header>
</article>

<article class=" hasvideo" >
<header>
<p class="title">
<a href="/hang-cong-nghe-thue-biet-thu-hawaii-cho-nhan-vien-nghi-duong-mien-phi-post744832.html">
Hãng công nghệ thuê biệt thự Hawaii cho nhân viên nghỉ dưỡng miễn phí
</a>
</p>
<time datetime="2017-05-10 06:00+0700"></time>
</header>
</article>
<article class="" >
<header>
<p class="title">
<a>Tai nghe In-ear Bluetooth đắt nhất thế giới</a></p>
<time datetime="2017-05-10 05:46+0700"></time>
</header>
</article>

<article class="" >
<header>
<p class="title">
<a>Loa thông minh Amazon Echo Show ra mắt với màn hình cảm ứng</a></p>
<time datetime="2017-05-09 21:56+0700"></time>
</header>
</article>

</div>
<article class="aside advertising" >
<p class="type"></p>
<div class="cover">
<a><img src="http://znews-photo-td.zadn.vn/w120/Uploaded/wyhktpu/2017_05_09/image005_5.jpg" alt="Nhung lan thay doi thiet ke man hinh an tuong cua Samsung hinh anh" title="Những lần thay đổi thiết kế màn hình ấn tượng của Samsung hình ảnh"></a>&nbsp;</div>
<header>
<p class="title">
<a>Những lần thay đổi thiết kế màn hình ấn tượng của Samsung</a></p>
<time datetime="2017-05-10 08:00+0700"></time>
</header>
</article>
</section>



<!-- section 12: Xe-360 -->
<section id="xe-360" class="category skin1">
<header>
<hgroup>
<h2><a title="Xe 360">Xe 360 </a></h2>
</hgroup>
<p><a>Xe máy</a></p>
<p><a>Ô-tô</a></p>
<p><a>Xe độ</a></p>
<p><a>Siêu xe</a></p>
</header>

<article class="featured picture" >
<p class="type"></p>
<header>
<p class="title">
<a>Chi tiết siêu môtô Honda CBR1000RR 2017 tại Việt Nam</a></p>
<time datetime="2017-05-10 06:00+0700"></time>
</header>
<div class="cover">
<a><img src="http://znews-photo-td.zadn.vn/w210/Uploaded/qfrqy/2017_05_09/Honda_CBR1000RR.JPG" alt="Chi tiet sieu moto Honda CBR1000RR 2017 tai Viet Nam hinh anh" title="Chi tiết siêu môtô Honda CBR1000RR 2017 tại Việt Nam hình ảnh"></a>&nbsp;</div>
<p class="summary">Honda CBR1000RR 2017 là mẫu superbike dung tích 1.000 phân khối, đối thủ của Yamaha R1, Ducati 1199 Panigale. </p>
<ul class="relate">
<li class=" advertising">
<a>Suzuki ra mắt 3 mẫu xe mới tại triển lãm môtô, xe máy 2017</a></li></ul>
</article>

<div class="top">
<article class=" video" >
<header>
<p class="title">
<a>Audi A3 bốc cháy sau khi va chạm trên đường</a></p>
<time datetime="2017-05-10 07:00+0700"></time>
</header>
</article>

<article class=" picture" >
<header>
<p class="title">
<a>SUV dã chiến giống Hummer cho người giàu Trung Quốc</a></p>
<time datetime="2017-05-10 05:43+0700"></time>
</header>
</article>

<article class=" picture hasvideo" >
<header>
<p class="title">
<a>Những mẫu xe concept độc đáo mới xuất hiện tại Việt Nam</a></p>
<time datetime="2017-05-09 19:42+0700"></time>
</header>
</article>

<article class=" hasvideo" >
<header>
<p class="title">
<a>Ôtô điện Tesla Model X đầu tiên về Việt Nam</a>
<span class="social hot">HOT</span><span class="comment_count">34</span></p>
<time datetime="2017-05-09 12:32+0700"></time>
</header>
</article>
</div>

<article class="aside picture" topic-id="2003">
<p class="type"></p>
<div class="cover">
<a><img src="http://znews-photo-td.zadn.vn/w120/Uploaded/zagtit/2017_05_09/sym_ellite_zing.jpg" alt="Loat xe may moi ra mat thi truong Viet Nam hinh anh" title="Loạt xe máy mới ra mắt thị trường Việt Nam hình ảnh"></a>&nbsp;</div>
<header>
<p class="title">
<a>Loạt xe máy mới ra mắt thị trường Việt Nam</a>
<span class="comment_count">7</span></p>
<time datetime="2017-05-09 15:26+0700"></time>
</header>
</article>
</section>



<!-- section 21: Am thuc -->
<section id="am-thuc" class="category skin1">
<header>
<hgroup>
<h2><a title="Ẩm thực">Ẩm thực </a></h2>
</hgroup>
<p><a>Địa điểm ăn uống</a></p>
<p><a>Món ngon</a></p>
<p><a title="Chiếc thìa vàng" target="_blank">Chiếc thìa vàng</a></p>
</header>

<article class="featured video" >
<p class="type"></p>
<header>
<p class="title">
<a>Bánh ngọt tráng miệng hình cây xương rồng</a></p>
<time datetime="2017-05-10 06:15+0700"></time>
</header>
<div class="cover">
<a><img src="http://znews-photo-td.zadn.vn/w210/Uploaded/tmuitg/2017_05_05/DOcJFxaFrRg4gtDEwOjIwbTowODE7WKmp4Still002.jpg" alt="Banh ngot trang mieng hinh cay xuong rong hinh anh" title="Bánh ngọt tráng miệng hình cây xương rồng hình ảnh"></a>&nbsp;</div>
<p class="summary">Jennifer Riley người Canada chế tạo ra những chiếc bánh ngọt với hình dáng là những cây xương rồng, khiến rất nhiều thực khách luôn hào hứng</p>
<ul class="relate">
<li class=" hasvideo">
<a>Cô bé 2 tuổi sở hữu kênh nấu ăn riêng trên Youtube</a></li></ul>
</article>

<div class="top">
<article class=" video" >
<header>
<p class="title">
<a>Làm dưa chuột ngâm muối</a></p>
<time datetime="2017-05-09 11:27+0700"></time>
</header>
</article>

<article class=" picture" >
<header>
<p class="title">
<a>Bữa ăn nhanh gọn với biến tấu cho món sandwich</a></p>
<time datetime="2017-05-08 13:15+0700"></time>
</header>
</article>

<article class=" picture" topic-id="392,2207">
<header>
<p class="title">
<a>10 địa chỉ ăn vặt không quảng cáo cũng đông khách của Sài Gòn</a>
<span class="social hot">HOT</span><span class="comment_count">19</span></p>
<time datetime="2017-05-08 06:33+0700"></time>
</header>
</article>

<article class=" picture" >
<header>
<p class="title">
<a>Ăn bánh mì ngon ở đâu Hà Nội?</a></p>
<time datetime="2017-05-07 13:03+0700"></time>
</header>
</article>
</div>

<article class="aside picture" topic-id="2208,647 ">
<p class="type"></p>
<div class="cover">
<a><img src="http://znews-photo-td.zadn.vn/w120/Uploaded/jaroin/2017_05_06/cafe_trung_top.jpg" alt="5 quan ca phe trung noi tieng khien thuc khach me man hinh anh" title="5 quán cà phê trứng nổi tiếng khiến thực khách mê mẩn hình ảnh"></a>&nbsp;</div>
<header>
<p class="title">
<a>5 quán cà phê trứng nổi tiếng khiến thực khách mê mẩn</a></p>
<time datetime="2017-05-09 07:00+0700"></time>
</header>
</article>
</section>



<!-- section 22:: Nhip song- Thong tin doanh nghiep -->
<section id="nhip-song" class="category skin4">
<header>
<hgroup>
<h2><a title="Nhịp sống">Nhịp sống </a></h2>
</hgroup>
</header>
<section id="nhip-song" class="category">
<header>
<h2><a title="Thông tin doanh nghiệp">Thông tin doanh nghiệp </a></h2>
</header>
<article class="featured" >
<div class="cover">
<a><img src="http://znews-photo-td.zadn.vn/w210/Uploaded/wyhktpu/2017_05_08/San_pham_ca_ba_sa_huu_co_va_tom_sinh_thai_thuong_hieu_Coop_Organic_cua_Saigon_Coop_dat__tieu_chuan_Mi_va_Chau_Au.jpg" alt="Thuc pham huu co chuan quoc te len ke tai 7 sieu thi lon Co.opmart hinh anh" title="Thực phẩm hữu cơ chuẩn quốc tế lên kệ tại 7 siêu thị lớn Co.opmart hình ảnh"></a>&nbsp;</div>
<header>
<p class="title">
<a>Thực phẩm hữu cơ chuẩn quốc tế lên kệ tại 7 siêu thị lớn Co.opmart</a></p>
<time datetime="2017-05-09 09:00+0700"></time>
</header>
<p class="summary">Liên hiệp Hợp tác xã Thương mại TP.HCM (Saigon Co.op) vừa chính thức giới thiệu ra thị trường 4 nhóm thực phẩm hữu cơ đạt tiêu chuẩn quốc tế mang thương hiệu Co.op Organic.</p>
</article>
<div class="top">

<article >
<header>
<p class="title">
<a>Máy làm đá Hải Âu và vai trò ‘phát ngôn viên’ thị trường</a></p>
<time datetime="2017-05-10 08:00+0700"></time>
</header>
</article>

<article >
<header>
<p class="title">
<a>Chùm ảnh cận cảnh 'chuyên gia selfie' Oppo F3</a></p>
<time datetime="2017-05-09 20:00+0700"></time>
</header>
</article>
</div>
</section>


<!-- section 23: Nhip song- Cuoi -->
<section id="nhip-song" class="category">
<header>
<h2><a title="Cười">Cười </a></h2>
</header>
<article class="featured" >
<div class="cover">
<a><img src="http://znews-photo-td.zadn.vn/w210/Uploaded/mdf_drywxd/2017_05_07/TaO_LE.jpg" alt="Cach giai bai toan sieu nhanh hinh anh" title="Cách giải bài toán siêu nhanh hình ảnh"></a>&nbsp;</div>
<header>
<p class="title">
<a>Cách giải bài toán siêu nhanh</a>
<span class="comment_count">9</span></p>
<time datetime="2017-05-08 07:39+0700"></time>
</header>
<p class="summary">Một cậu bé tới trước hàng bán hoa quả hỏi: "Ông ơi , cho cháu hỏi bao nhiêu tiền một cân táo vậy?".</p>
</article>

<div class="top">
<article>
<header>
<p class="title">
<a>Thanh niên cứng của năm</a>
<span class="comment_count">7</span></p>
<time datetime="2017-04-18 20:44+0700"></time>
</header>
</article>

<article >
<header>
<p class="title">
<a>Vợ anh đã ngủ rồi</a>
<span class="comment_count">7</span></p>
<time datetime="2017-03-30 11:24+0700"></time>
</header>
</article>
</div>
</section>



<!-- section 24: Sach hay -->
<section id="sach-hay" class="category">
<header>
<h2><a title="Sách hay">Sách 360 </a></h2>
</header>
<article class="featured" >
<div class="cover">
<a><img src="http://znews-photo-td.zadn.vn/w210/Uploaded/neg_iflemly/2017_05_07/trc6b0c6a1ngkimc491e1bb8bnh_thumb.jpg" alt="Tai ban bo sach triet ly an vi cua Kim Dinh hinh anh" title="Tái bản bộ sách triết lý an vi của Kim Định hình ảnh"></a></div>
<header>
<p class="title">
<a>Tái bản bộ sách triết lý an vi của Kim Định</a></p>
<time datetime="2017-05-09 17:00+0700"></time>
</header>
<p class="summary">Đây là một bộ sách triết học có giá trị và rất thú vị với bạn đọc quan tâm vấn đề này.</p>
</article>

<div class="top">
<article>
<header>
<p class="title">
<a>Tớ nên tin vào điều gì?': Lòng tin là cội nguồn của hạnh phúc</a></p>
<time datetime="2017-05-09 13:34+0700"></time>
</header>
</article>
<article >
<header>
<p class="title">
<a>Cuốn sách giúp ta sống hướng thiện và tử tế</a></p>
<time datetime="2017-05-09 06:37+0700"></time>
</header>
</article>
</div>
</section>
</section>
</div>
</div>




<section class="sidebar">
<!-- End 123.vn -->
<!-- section 25: Tin anh -->
<section class="pictures">
<header>
<h2><a href="/pictures">Tin ảnh</a></h2>
</header>
<div class="slidebox">
<article class="current" topic-id="2003">
<div class="cover">
<a><img src="http://znews-photo-td.zadn.vn/w480/Uploaded/zagtit/2017_05_09/sym_ellite_zing.jpg" alt="Loat xe may moi ra mat thi truong Viet Nam hinh anh" title="Loạt xe máy mới ra mắt thị trường Việt Nam hình ảnh"></a></div>
<header>
<p class="title">
<a>Loạt xe máy mới ra mắt thị trường Việt Nam </a>
<span class="comment_count">7</span>
</p>
<time datetime="2017-05-09 15:26+0700"></time>
</header>
</article>
</section>



<!-- Start Box Sidebar -->
<!-- section 26: Video -->
<section class="video">
<header>
<h2><a>Video</a></h2>
</header>
<article class="featured video" topic-id="2121,3525">
<p class="type"> video</p>
<div class="cover">
<a>
<img src="http://znews-photo-td.zadn.vn/w480/Uploaded/oqivovbv/2017_05_09/photo111494215630678360533799crop1494215668290.jpg" alt="#Highlight ngay 9/5: Top 5 tin tuc phai xem trong ngay hinh anh" title="#Highlight ngày 9/5: Top 5 tin tức phải xem trong ngày hình ảnh">
</a>
</div>
<header>
<p class="title"
><a>#Highlight ngày 9/5: Top 5 tin tức phải xem trong ngày</a></p>
<time datetime="2017-05-09 18:34+0700"></time>
</header>
</article>

<article class=" video" topic-id="2121">
<p class="type"> video</p>
<div class="cover">
<a><img src="http://znews-photo-td.zadn.vn/w480/Uploaded/ohunuai/2017_05_08/2Untitled.jpg" alt="Clip Minh Beo xin loi khan gia hinh anh" title="Clip Minh Béo xin lỗi khán giả hình ảnh"></a></div>
<header>
<p class="title"><a>Clip Minh Béo xin lỗi khán giả</a></p>
<time datetime="2017-05-09 05:53+0700"></time>
</header>
</article>

<article class=" video" topic-id="2121">
<p class="type"> video hasvideo</p>
<div class="cover">
<a><img src="http://znews-photo-td.zadn.vn/w480/Uploaded/iutmtn/2017_05_08/heo_1_thumb.jpg" alt="Mot con heo cong lung ‘cong’ 51 khoan thue, phi hinh anh" title="Một con heo còng lưng ‘cõng’ 51 khoản thuế, phí hình ảnh"></a></div>
<header>
<p class="title"><a>Một con heo còng lưng ‘cõng’ 51 khoản thuế, phí</a></p>
<time datetime="2017-05-09 07:50+0700"></time>
</header>
</article>
</section>



<!-- section 27: Doc nhieu nhat -->
<section class="order-list">
<header>
<h2><a title="Đọc nhiều nhất">Đọc nhiều nhất</a></h2>
</header>
<article >
<span class="order">1</span>
<div class="cover">
<a><img src="http://znews-gif-td.zadn.vn/Uploaded/ohunuai/2017_05_08/minhbeo1.gif" alt="Minh Beo khoc nuc no xin loi, khan gia che gia doi hinh anh" title="Minh Béo khóc nức nở xin lỗi, khán giả chê giả dối hình ảnh"></a></div>
<header>
<p class="title">
<a>Minh Béo khóc nức nở xin lỗi, khán giả chê giả dối</a>
<span class="social hot">HOT</span>
<span class="comment_count">503</span>
</p>
<time datetime="2017-05-09 05:52+0700"></time>
<p class="cate">Sao Việt</p>
</header>
</article>

<article topic-id="3393 ">
<span class="order">2</span>
<div class="cover">
<a><img src="http://znews-photo-td.zadn.vn/w480/Uploaded/wpdhnwww3/2017_05_07/thumb__1.jpg" alt="Hi - Chao buoi sang 9/5 hinh anh" title="Hi - Chào buổi sáng 9/5 hình ảnh"></a>
</div>
<header>
<p class="title">
<a>Hi - Chào buổi sáng 9/5</a>
</p>
<time datetime="2017-05-09 00:00+0700"></time>
<p class="cate">#Highlight</p>
</header>
</article>

<article topic-id="2121,3525">
<span class="order">3</span>
<div class="cover">
<a><img src="http://znews-photo-td.zadn.vn/w480/Uploaded/oqivovbv/2017_05_09/photo111494215630678360533799crop1494215668290.jpg" alt="#Highlight ngay 9/5: Top 5 tin tuc phai xem trong ngay hinh anh" title="#Highlight ngày 9/5: Top 5 tin tức phải xem trong ngày hình ảnh"></a>
</div>
<header>
<p class="title">
<a>#Highlight ngày 9/5: Top 5 tin tức phải xem trong ngày</a></p>
<time datetime="2017-05-09 18:34+0700"></time>
<p class="cate">#Highlight</p>
</header>
</article>

<article topic-id="3393 ">
<span class="order">4</span>
<div class="cover">
<a><img src="http://znews-photo-td.zadn.vn/w480/Uploaded/wpdhnwww3/2017_05_08/thumb.jpg" alt="Hi - Chao buoi sang 10/5 hinh anh" title="Hi - Chào buổi sáng 10/5 hình ảnh"></a></div>
<header>
<p class="title">
<a>Hi - Chào buổi sáng 10/5</a></p>
<time datetime="2017-05-10 00:00+0700"></time>
<p class="cate">#Highlight</p>
</header>
</article>

<article topic-id="2001">
<span class="order">5</span>
<div class="cover">
<a href="/chu-hang-xoi-doanh-thu-60-trieu-dongngay-len-tieng-chuyen-dong-cua-post744897.html">
<img src="http://znews-photo-td.zadn.vn/w480/Uploaded/iutmtn/2017_05_09/xoi_1.jpg" alt="Chu hang xoi doanh thu 60 trieu dong/ngay len tieng chuyen dong cua hinh anh" title="Chủ hàng xôi doanh thu 60 triệu đồng/ngày lên tiếng chuyện đóng cửa hình ảnh">
</a>
</div>
<header>
<p class="title">
<a>Chủ hàng xôi doanh thu 60 triệu đồng/ngày lên tiếng chuyện đóng cửa</a>
<span class="comment_count">56</span>
</p>
<time datetime="2017-05-09 18:06+0700"></time>
<p class="cate">Kinh doanh</p>
</header>
</article>
</section>



<!-- section 28: Thong tin doanh nghiep -->
<section id="promotedposts">
<header>
<h2><a title="Thông tin doanh nghiệp">Thông tin doanh nghiệp </a></h2>
</header>
<article >
<div class="cover">
<a>
<img src="http://znews-photo-td.zadn.vn/w480/Uploaded/wyhktpu/2017_05_08/h2_1.jpg" alt="May lam da Hai Au va vai tro ‘phat ngon vien’ thi truong hinh anh" title="Máy làm đá Hải Âu và vai trò ‘phát ngôn viên’ thị trường hình ảnh">
</a>
</div>
<header>
<p class="title"></p>
<a>Máy làm đá Hải Âu và vai trò ‘phát ngôn viên’ thị trường</a></p>
</header>
</article>

<article >
<div class="cover">
<a>
<img src="http://znews-photo-td.zadn.vn/w480/Uploaded/wyhktpu/2017_05_09/image003_6.jpg" alt="Chum anh can canh &#39;chuyen gia selfie&#39; Oppo F3 hinh anh" title="Chùm ảnh cận cảnh &#39;chuyên gia selfie&#39; Oppo F3 hình ảnh"></a></div>
<header>
<p class="title"></p>
<a>Chùm ảnh cận cảnh 'chuyên gia selfie' Oppo F3</a></p>
</header>
</article>

<article>
<div class="cover">
<a><img src="http://znews-photo-td.zadn.vn/w480/Uploaded/wyhktpu/2017_05_09/image004_2.jpg" alt="Heropharm dat top 10 thuong hieu tieu bieu chau A - TBD 2017 hinh anh" title="Heropharm đạt top 10 thương hiệu tiêu biểu châu Á - TBD 2017 hình ảnh"></a></div>
<header>
<p class="title"></p>
<a>Heropharm đạt top 10 thương hiệu tiêu biểu châu Á - TBD 2017</a></p>
</header>
</article>

<article>
<div class="cover">
<a><img src="http://znews-photo-td.zadn.vn/w480/Uploaded/wyhktpu/2017_05_09/image001_3.jpg" alt="Viet Thuong khai truong co so moi tai TP.HCM hinh anh" title="Việt Thương khai trương cơ sở mới tại TP.HCM hình ảnh"></a></div>
<header>
<p class="title"></p>
<a>Việt Thương khai trương cơ sở mới tại TP.HCM</a></p>
</header>
</article>

<article >
<div class="cover">
<a><img src="http://znews-photo-td.zadn.vn/w480/Uploaded/wyhktpu/2017_05_08/ctkm.jpg" alt="Gioi tre san lung goi Facebook Data 3.000 dong/ngay de gianh Mazda 6 hinh anh" title="Giới trẻ săn lùng gói Facebook Data 3.000 đồng/ngày để giành Mazda 6 hình ảnh"></a></div>
<header>
<p class="title"></p>
<a>Giới trẻ săn lùng gói Facebook Data 3.000 đồng/ngày để giành Mazda 6</a></p>
</header>
</article>

<article >
<div class="cover">
<a>
<img src="http://znews-photo-td.zadn.vn/w480/Uploaded/wyhktpu/2017_05_08/San_pham_ca_ba_sa_huu_co_va_tom_sinh_thai_thuong_hieu_Coop_Organic_cua_Saigon_Coop_dat__tieu_chuan_Mi_va_Chau_Au.jpg" alt="Thuc pham huu co chuan quoc te len ke tai 7 sieu thi lon Co.opmart hinh anh" title="Thực phẩm hữu cơ chuẩn quốc tế lên kệ tại 7 siêu thị lớn Co.opmart hình ảnh"></a></div>
<header>
<p class="title"></p>
<a>Thực phẩm hữu cơ chuẩn quốc tế lên kệ tại 7 siêu thị lớn Co.opmart</a></p>
</header>
</article>

<article >
<div class="cover">
<a><img src="http://znews-photo-td.zadn.vn/w480/Uploaded/wyhktpu/2017_05_08/image005.jpg" alt="Bi quyet chup anh cuoi dep nhu mo tai Da Lat hinh anh" title="Bí quyết chụp ảnh cưới đẹp như mơ tại Đà Lạt hình ảnh"></a></div>
<header>
<p class="title"></p>
<a>Bí quyết chụp ảnh cưới đẹp như mơ tại Đà Lạt</a></p>
</header>
</article>

<article >
<div class="cover">
<a><img src="http://znews-photo-td.zadn.vn/w480/Uploaded/wyhktpu/2017_05_08/image004_1.jpg" alt="Hon 8.000 nguoi dan mien Tay da tu hoi tai le hoi bia Chi cot hinh anh" title="Hơn 8.000 người dân miền Tây đã tụ hội tại lễ hội bia Chí cốt hình ảnh"></a></div>
<header>
<p class="title"></p>
<a>Hơn 8.000 người dân miền Tây đã tụ hội tại lễ hội bia Chí cốt</a></p>
</header>
</article>
</section>
</section>
</section>
</div>



<!-- Thong tin Zing.vn -->
<footer>
<div class="copyright">
<div class="logo">
<a><img src="http://stc.v3.news.zing.vn/images/zing_footer_logo.jpg" width="130" width="55" /></a>
<p><a href="http://adtima.vn/ratecard" target="_blank">Quảng cáo</a></p></div>
<p class="info vcard">Giấy phép báo điện tử số: 236/GP-BTTTT. Tổng Biên tập: Ngô Việt Anh<br />
Cơ quan chủ quản: Hội Xuất bản Việt Nam.<br />
Tòa soạn: D29 Trần Thái Tông, Cầu Giấy, Hà Nội.<br />
<i>Chỉ được phát hành lại thông tin từ website này khi có sự đồng ý bằng văn bản của báo.</i>
</p>
</div>
</footer>


</body>
</html>