<?php	 	
	 $conn = mysqli_connect('localhost','root','','bigdata') 	
	 	 or die("Unable connect to MySQL: " . mysqli_error() ."<br>");	
	 	
	 if (isset($_FILES["img_file"]["name"]) && getimagesize($_FILES['img_file']['tmp_name']) != false)	
	 {	
	 	 //CHECK CONTRAINTS if any ...	
	 	 $image = file_get_contents($_FILES['img_file']['tmp_name']);	
	 	 $image = addslashes($image);	
	 	 $imgname = $_FILES["img_file"]["name"];	
	 	 $add = "INSERT INTO IMAGE (NAMEI , NDANH) VALUES ('$imgname', '$image')";
	 	 // echo $image;
	 	 $result=mysqli_query($conn, $add);
	 	if(mysqli_affected_rows($conn)) {
	 		echo mysqli_affected_rows($conn);
			// header("Location:google.com.vn");
		} 
		else{
			header("Location:vnexpres.net");
		}
	 	
	 	echo "Uploaded image: <br><img src='get_img.php?name=$imgname'/>";	
	 }	
	 else 	
	 	 echo "No image has been uploaded";	

	 	echo '<img height = "300" width = "200" src = "" ';
?>