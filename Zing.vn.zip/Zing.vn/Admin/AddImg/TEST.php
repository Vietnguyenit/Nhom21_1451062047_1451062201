
<?php 
$conn = mysqli_connect('localhost', 'root', '', 'bigdata');
// mysqli_set_charset($conn,'UTF8');
$sql= "SELECT * FROM IMAG WHERE IDIMG = '1' ";
$result = mysqli_query($conn,$sql) or die("Cannot".mysqli_error());
if (mysqli_num_rows($result) >0) {
	$row =mysqli_fetch_assoc($result);
	$imgdata = $row ['NAME'];
	header("Content-type:png");
	echo $imgdata;
}
else
{
	 echo "<script type='text/javascript'>alert('failed!')</script>";
}
 ?>
 	