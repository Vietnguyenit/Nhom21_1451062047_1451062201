<?php

	$conn = mysqli_connect('localhost', 'root', '', 'bigdata');

	$email = $_POST['email'];
	$password = $_POST['password'];


	$email = stripcslashes($email);
	$password = stripcslashes($password);
	$email = mysqli_real_escape_string($conn , $email);
	$password = mysqli_real_escape_string($conn , $password);



	$results = mysqli_query($conn , "select * from LOGINUS where EMAIL = '$email' and PASSWORD = '$password'") 
															or die("failed to query database".mysqli_error());
 	$row  = mysqli_fetch_array($results);
 	for($i= 0 ; $i<=5 ; $i++){

 		if($row['EMAIL'] == $email && $row['PASSWORD'] = $password){
			header("Location:../BaiViet/Baiviet.php");
		}
		else
		{
			header("Location:success.php");
		}
 	}
 		
	mysqli_close($conn);

 ?>
