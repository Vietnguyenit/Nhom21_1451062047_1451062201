<?php 
		$conn = mysqli_connect('localhost', 'root', '', 'bigdata');

		session_start();

		// $email = $_POST['email'];
		// $password = $_POST['password'];

		function get_user($email , $password){

			$sql =  "SELECT * FROM LOGIN WHERE EMAIL = '$email' AND PASSWORD = '$password'";
			$conn = mysqli_connect('localhost', 'root', '', 'bigdata');
			$results = mysqli_query($conn , $sql) or die("failed to query database".mysqli_error());

			if(mysqli_num_rows($results) > 0 ){
				$row = mysqli_fetch_array($results);
				$_SESSION['currentUser'] = $row['EMAIL'];
				if($row['ROLE'] == 'ADMIN'){
					$_SESSION['currentAdmin'] = $row['ROLE'];
					header("Location:../BaiViet/Baiviet.php");

				} elseif ($row['ROLE'] == 'MEMBER' AND $row['IDCMUC'] == '1') {
					header("Location:../Image/Image.php"); // phai thuc hien truy van lay ra theo quyen cua nguoi dung 
				} else{
					header("Location:../Video/Video.php");
				}
			}
			else{
				echo "<script> alert ('Email or Password is not incorrect') </script>";
			}
		}
		mysqli_close($conn);
 ?>