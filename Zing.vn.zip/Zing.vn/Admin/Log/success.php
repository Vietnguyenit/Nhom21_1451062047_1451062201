<?php 
        require ("Permission.php");

        if($_SERVER['REQUEST_METHOD'] == 'POST'){
            $email = $_POST['email'];
            $password = $_POST['password'];
            get_user($email , $password);
        }
 ?>

<!DOCTYPE html>
<html>
<head>
    <title>LOGIN</title>
     <meta http-equiv="Content-type" content="text/html; charset=utf-8" />
        <script src="../js/jquery-1.12.2.min.js" type="text/javascript"></script>
        <script src="../js/validate_jquery_plugin/jquery.validate.js" type="text/javascript"></script>
        <script src="../js/common.js" type="text/javascript"></script>
        <link href="../css/validate_jquery_plugin/screen.css" type="text/css" rel="stylesheet">
        <link href="../css/styles.css" type="text/css" rel="stylesheet">
</head>
<body>
<div class="signup_form">
    <form name="signup_form" action="" method="POST" id="signup_form">
        <div class="form_title">LOGIN
        </div>
         <div>
            <label>Email</label>
            <input class="input_text" name="email" id="email" placeholder="Email">
            <div id ="mes"></div>
        </div>
        <div>
            <label>Password</label>
            <input class="input_text" type="password" id="password" name="password" placeholder="Password">
        </div>
        <div class="btn_signup">
            <button type="submit">LOGIN</button>
        </div>
    </form>
</div>
</body>
</html>

<!-- USE SESSION CHECK LOGIN WHEN NEW PAGE (ADMIN) AHEAD HTML--> 




