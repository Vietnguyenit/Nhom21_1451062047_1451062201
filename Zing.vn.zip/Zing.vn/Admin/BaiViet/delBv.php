<?php 
	$conn = mysqli_connect('localhost', 'root', '', 'bigdata');

	
	if (isset($_GET['id_bv']) && is_numeric($_GET['id_bv']))
	{
	
	$id = $_GET['id_bv'];

	
	if ($stmt = $mysqli->prepare("DELETE FROM BAIVIET WHERE ID_BAIVIET = ? LIMIT 1"))
	{
	$stmt->bind_param("i",$id);
	$stmt->execute();
	$stmt->close();
	}
	else
	{
	echo "ERROR: could not prepare SQL statement.";
	}
	$mysqli->close();

	// redirect user after delete is successful
	header("Location: Baiviet.php");
	}
	else
	// if the 'id' variable isn't set, redirect the user
	{
	header("Location: s.php");
	}

?>
