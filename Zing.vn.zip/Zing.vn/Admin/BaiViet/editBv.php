<?php 
	$conn = mysqli_connect('localhost', 'root', '', 'bigdata');
	mysqli_set_charset($conn , 'UTF8');

	$id_bv = $_POST['id_bv'];
	$id_dm = $_POST['id_dm'];
	$time = $_POST['time'];
	$title = $_POST['title'];
	$summ = $_POST['summ'];
	$cont1 = $_POST['contnent1'];
	$cont2 = $_POST['contnent2'];
	$cont3 = $_POST['contnent3'];
	$cont4 = $_POST['contnent4'];
	$id_img = $_POST['id_img'];
	$id_vd = $_POST['id_vid'];
	$reporter = $_POST['reporter'];


	$add = "UPDATE BAIVIET SET 
		ID_DMUC ='$id_bv',THOIGIAN ='$time',TIEUDE ='$title',TOMTAT ='$summ',NOIDUNG1 ='$cont1',NOIDUNG2 ='$cont2',NOIDUNG3 ='$cont3',NOIDUNG4 ='$cont4',IDIMAGE ='$id_img',IDVIDEO ='$id_vd' TACGIA ='$reporter' 
		WHERE IDBAIVIET ='$id_bv'";

	if(mysqli_query($conn , $add) == TRUE){
			header("Location:Baiviet.php");
		} 
	else{
			header("Location:AddBv.php");
		}

	mysqli_close($conn);

 ?>