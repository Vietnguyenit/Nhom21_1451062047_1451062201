<?php 
	$conn = mysqli_connect('localhost', 'root', '', 'bigdata');

	$idcmuc = $_POST['id_cmuc'];
	$name = $_POST['img'];
	$content = $_POST['content'];
	

	$add = "UPDATE IMAGE SET  
			NAMEIMG = '$name', CONTENTIMG ='$content' , IDCMUC = '$idcmuc' WHERE IDIMAGE = '$id' " ;
		
	if(mysqli_query($conn , $add)){
			header("Location:Image.php");
		} 
	else{
			header("Location:AddImg.php");
		}

	mysqli_close($conn);

 ?>