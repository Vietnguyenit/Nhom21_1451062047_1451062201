    <?php 

        $conn = mysqli_connect('localhost', 'root', '','bigdata');
        mysqli_set_charset($conn , 'UTF8'); // must
        $res = mysqli_query($conn , "select * from DANHMUC");

     ?>
<!DOCTYPE html>
<html>
<head>
    <title>THÊM HÌNH ẢNH</title>
     <meta http-equiv="Content-type" content="text/html; charset=utf-8" />
        <link href="../css/validate_jquery_plugin/screen.css" type="text/css" rel="stylesheet">
        <link href="../css/styles.css" type="text/css" rel="stylesheet">
</head>
<body>
<div class="signup_form">
    <form name="signup_form" action="addImg.php" method="POST" id="signup_form">
        <div class="form_title">Thêm Hình ảnh
        </div>

         <div>
            <label>Mã Hình ảnh</label>
            <input class="input_text" name="id_img" id="id_img" placeholder="Auto_Increment">
        </div>

	 <div>
            <label>Tên hình ảnh</label>
            <input class="input_text" name="img" id="img" placeholder="Nhập Tên Hình ảnh ">
        </div>

	 <div>
            <label>Đường dẫn hình ảnh</label>
            <input class="input_text" name="content" id="content" type = "text">
        </div>

         <div>
           <label>Chuyên mục</label>
                <select multiple name = "id_cm" id = "id_cm">
                    <?php 
                            $sql = "SELECT * FROM DANHMUC";
                            $res = mysqli_query($conn , $sql);
                              
                        while($row = mysqli_fetch_array($res)){
                    ?>
                      <option value="<?php echo $row[0] ; ?>" >
                    <?php
                            echo $row[1] ;
                    ?>
                    </option>
                    <?php } ?>
                </select>
        </div>

        <div class="btn_signup">
            <button type="submit">THÊM HÌNH ẢNH</button>
        </div>
    </form>
</div>
</body>
</html>



