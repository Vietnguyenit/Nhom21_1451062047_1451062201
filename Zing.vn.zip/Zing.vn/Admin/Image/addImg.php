<?php 
	$conn = mysqli_connect('localhost', 'root', '', 'bigdata');
	mysqli_set_charset($conn , 'UTF8');

	$idcmuc = $_POST['id_cmuc'];
	$name = $_POST['img'];
	$content = $_POST['content'];
	

	$add = "INSERT INTO IMAGE VALUES ('$name','$content', '$idcmuc')";
		
	if(mysqli_query($conn , $add)){
			header("Location:Image.php");
		} 
	else{
			header("Location:Addimg.php");
		}

	mysqli_close($conn);

 ?>
