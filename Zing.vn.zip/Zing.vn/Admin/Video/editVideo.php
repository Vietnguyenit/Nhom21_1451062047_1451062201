<?php 
	$conn = mysqli_connect('localhost', 'root', '', 'bigdata');

	$id = $_POST['id_vd'];
	$name = $_POST['video'];
	$content = $_POST['content'];
	

	$add = "UPDATE VIDEO SET NAMEVD='$name',NDUNGVD='$content' WHERE IDVIDEO='$id' " ;
		
	if(mysqli_query($conn , $add) == TRUE){
			header("Location:results.php");
		} 
	else{
			header("Location:AddVideo.php");
		}

	mysqli_close($conn);

 ?>