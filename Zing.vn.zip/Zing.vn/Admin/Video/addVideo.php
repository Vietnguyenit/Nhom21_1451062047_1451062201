<?php 
	$conn = mysqli_connect('localhost', 'root', '', 'bigdata');
	mysqli_set_charset($conn , 'UTF8');

	$id_cmuc = $_POST['id_cmuc'];
	$name = $_POST['video'];
	$content = $_POST['content'];
	

	$add = "INSERT INTO VIDEO VALUES ('$name','$content', '$id_cmuc',)";
		
	if(mysqli_query($conn , $add) == TRUE){
			header("Location:Video.php");
		} 
	else{
			header("Location:AddVideo.php");
		}

	mysqli_close($conn);

 ?>
