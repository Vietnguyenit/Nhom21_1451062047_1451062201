<!DOCTYPE html>
<html>
<head>
    <title>THÊM VIDEO</title>
     <meta http-equiv="Content-type" content="text/html; charset=utf-8" />
        <link href="../css/validate_jquery_plugin/screen.css" type="text/css" rel="stylesheet">
        <link href="../css/styles.css" type="text/css" rel="stylesheet">
</head>
<body>
<div class="signup_form">
    <form name="signup_form" action="addVideo.php" method="POST" id="signup_form">
        <div class="form_title">Thêm Video
        </div>

         <div>
            <label>Mã Video</label>
            <input class="input_text" name="id_vd" id="id_vd" placeholder="Auto_Increment">
        </div>

	 <div>
            <label>Tên Video</label>
            <input class="input_text" name="video" id="video" placeholder="Nhập Tên video">
        </div>

	 <div>
            <label>Đường dẫn video</label>
            <input class="input_text" name="content" id="content" type = "text">
        </div>

	 <div>
            <label>Chuyên mục</label>
            <input class="input_text" name="content" id="content" type = "text">
        </div>

        <div class="btn_signup">
            <button type="submit">THÊM VIDEO</button>
        </div>
    </form>
</div>
</body>
</html>



